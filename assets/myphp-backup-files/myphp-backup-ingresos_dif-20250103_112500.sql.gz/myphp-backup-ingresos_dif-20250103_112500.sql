CREATE DATABASE IF NOT EXISTS `ingresos_dif`;

USE `ingresos_dif`;

SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `apertura_caja`;

CREATE TABLE `apertura_caja` (
  `id_caja` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `monto_apertura` decimal(10,2) NOT NULL,
  `fecha_apertura` date NOT NULL,
  PRIMARY KEY (`id_caja`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `apertura_caja` VALUES (1,1,"100.00","2024-12-11"),
(2,1,"100.00","2024-12-23"),
(3,1,"100.00","2024-12-24"),
(4,1,"100.00","2025-01-02"),
(5,1,"100.00","2025-01-03");


DROP TABLE IF EXISTS `consecutivo_folio`;

CREATE TABLE `consecutivo_folio` (
  `id_consecutivo` int(11) NOT NULL AUTO_INCREMENT,
  `numero_folio` int(11) NOT NULL,
  `is_pago` int(11) NOT NULL,
  PRIMARY KEY (`id_consecutivo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



DROP TABLE IF EXISTS `tc_categoria`;

CREATE TABLE `tc_categoria` (
  `categoria_id` int(11) NOT NULL AUTO_INCREMENT,
  `categoria_nombre` varchar(100) NOT NULL,
  PRIMARY KEY (`categoria_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tc_categoria` VALUES (2,"Dental"),
(3,"Médico General"),
(4,"Psicólogo"),
(5,"Preescolar"),
(6,"Rehabilitación"),
(7,"Otro");


DROP TABLE IF EXISTS `tc_conceptos`;

CREATE TABLE `tc_conceptos` (
  `concepto_id` int(11) NOT NULL AUTO_INCREMENT,
  `categoria_id` int(11) NOT NULL,
  `concepto_nombre` varchar(100) NOT NULL,
  `concepto_precio` decimal(10,2) NOT NULL,
  PRIMARY KEY (`concepto_id`),
  KEY `categoria_id` (`categoria_id`),
  CONSTRAINT `tc_conceptos_ibfk_1` FOREIGN KEY (`categoria_id`) REFERENCES `tc_categoria` (`categoria_id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tc_conceptos` VALUES (2,3,"Consulta General","102.64"),
(3,2,"Extracción dental","169.05"),
(4,2,"Limpieza dental","239.50"),
(5,2,"Colocación de amalgamas","169.05"),
(6,4,"Psicólogo","102.64"),
(7,7,"Optometrista","58.34"),
(8,6,"Por terapia de rehabilitación, en sus diversos tipos","80.53"),
(9,7,"Traslado dentro de la cabecera Municipal","35.00"),
(10,7,"Traslado a comunidades dentro de la cabecera Municipal","47.00"),
(11,7,"Traslado a la ciudad de Irapuato","176.00"),
(12,7,"Traslado a la ciudad de Silao y León","293.00"),
(13,7,"Traslado particular de persona a la ciudad de Irapuato","352.00"),
(14,7,"Traslado particular de persona a la ciudad de León","704.00"),
(15,7,"Traslado particular de persona a la ciudad de Celaya","505.00"),
(16,7,"Traslado particular de persona a la ciudad de Morelia","337.00"),
(17,5,"Cuota por alumno mensual, por el ciclo escolar.","29.00"),
(18,5,"Cuota por alumno anual, por el ciclo escolar","235.00"),
(19,7,"Carta de tutoría provisional","29.00"),
(20,7,"Por asesoría Jurídica","29.00"),
(21,7,"Carta de convivencia para contraer matrimonio","41.00"),
(22,7,"Por visita domiciliaria de trabajo social","94.00"),
(23,7,"Pericial en trabajo social","869.00"),
(24,7,"Prueba pericial en psicología","1174.00"),
(25,7,"Constancia de discapacidad para tramite externo","35.00"),
(26,7,"Servicio de reposición de carnet de citas","24.00"),
(27,7,"Convivencia asistida por trabajo social por hora","130.00"),
(28,7,"Con credencial de discapacidad o adulto mayor","5.00"),
(29,7,"Sin credencial de discapacidad","10.00"),
(30,7,"Por Servicios de Asesoría Jurídica en materia de juicios","1638.00"),
(32,7,"Asistencia y Salud Publica, Prestación de Servicios, Aplicación de Resina Dental","194.00"),
(35,7,"Estudio Socioeconómico","93.00"),
(36,7,"Desayuno en Comedores","12.00");


DROP TABLE IF EXISTS `tc_configuracion`;

CREATE TABLE `tc_configuracion` (
  `id_config` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_empresa` varchar(150) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `dependencia` varchar(150) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `logo_url` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id_config`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tc_configuracion` VALUES (1,"Sistema de Ingresos DIF","DIF","assets/img/1732044945_AdminLTELogo.png");


DROP TABLE IF EXISTS `tc_contribuyentes`;

CREATE TABLE `tc_contribuyentes` (
  `contribuyente_id` int(11) NOT NULL AUTO_INCREMENT,
  `contribuyente_nombre` varchar(100) NOT NULL,
  `contribuyente_domicilio` varchar(255) DEFAULT NULL,
  `contribuyente_ciudad` varchar(100) DEFAULT NULL,
  `contribuyente_added` timestamp NOT NULL DEFAULT current_timestamp(),
  `contribuyente_estatus` enum('activo','inactivo') DEFAULT 'activo',
  PRIMARY KEY (`contribuyente_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tc_contribuyentes` VALUES (1,"Publico en General","Uriangato","Uriangato","2024-11-21 13:44:40","activo"),
(2,"Felix Omar Ramirez Vazquez","Morelos #1","Uriangato","2024-11-21 14:19:11","activo");


DROP TABLE IF EXISTS `tc_usuarios`;

CREATE TABLE `tc_usuarios` (
  `usuario_id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_nombre` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `usuario_apellido` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `usuario_password_hash` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `usuario_usuario` varchar(64) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `is_admin` int(11) NOT NULL,
  `date_added` datetime NOT NULL,
  `usuario_foto` varchar(150) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT 'assets/images/prefil/user2-160x160.jpg',
  PRIMARY KEY (`usuario_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='user data';

INSERT INTO `tc_usuarios` VALUES (1,"Felix Omar","Ramirez Vazquez","$argon2id$v=19$m=65536,t=4,p=1$OFNtOHFUV3hCOUdhUFkuaQ$CCVTHGx3pHiMCQ2ymvm3wfSIGIq4xowICSrHaEnj+XA","webmaster",1,"2024-10-21 15:06:00","assets/images/prefil/1731606665_logo-oficial-min.png"),
(4,"Cajero","DIF","$argon2id$v=19$m=65536,t=4,p=1$bE9BMno4SkJMTEJiV3BxTQ$Ak25S9SB9bkChb4mo98Fqlq13iK6VKynCI1iupMw2WA","Cajero",3,"2025-01-03 18:24:35","assets/images/prefil/user2-160x160.jpg");


DROP TABLE IF EXISTS `venta_detalles`;

CREATE TABLE `venta_detalles` (
  `detalle_id` int(11) NOT NULL AUTO_INCREMENT,
  `venta_id` int(11) NOT NULL,
  `concepto_id` int(11) NOT NULL,
  `cantidad` decimal(10,2) NOT NULL,
  `precio_unitario` decimal(10,2) NOT NULL,
  `subtotal` decimal(10,2) NOT NULL,
  PRIMARY KEY (`detalle_id`),
  KEY `idx_detalle_venta` (`venta_id`),
  KEY `idx_detalle_concepto` (`concepto_id`),
  CONSTRAINT `venta_detalles_ibfk_1` FOREIGN KEY (`venta_id`) REFERENCES `ventas` (`venta_id`),
  CONSTRAINT `venta_detalles_ibfk_2` FOREIGN KEY (`concepto_id`) REFERENCES `tc_conceptos` (`concepto_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `venta_detalles` VALUES (1,1,2,"1.00","98.69","98.69"),
(2,2,2,"1.00","98.69","98.69"),
(3,3,5,"1.00","162.55","162.55"),
(4,4,11,"1.00","169.00","169.00"),
(5,5,2,"1.00","98.69","98.69"),
(6,6,2,"1.00","102.64","102.64"),
(7,7,19,"1.00","29.00","29.00");


DROP TABLE IF EXISTS `ventas`;

CREATE TABLE `ventas` (
  `venta_id` int(11) NOT NULL AUTO_INCREMENT,
  `contribuyente_id` int(11) NOT NULL,
  `fecha` date NOT NULL DEFAULT current_timestamp(),
  `total` decimal(10,2) NOT NULL,
  `descuento` decimal(10,2) DEFAULT 0.00,
  `estado` enum('activo','cancelado') DEFAULT 'activo',
  `titulo_descuento` varchar(255) NOT NULL,
  PRIMARY KEY (`venta_id`),
  KEY `idx_venta_contribuyente` (`contribuyente_id`),
  CONSTRAINT `ventas_ibfk_1` FOREIGN KEY (`contribuyente_id`) REFERENCES `tc_contribuyentes` (`contribuyente_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `ventas` VALUES (1,1,"2024-12-23","98.69","0.00","activo",""),
(2,2,"2024-12-23","98.69","0.00","activo",""),
(3,1,"2024-12-24","162.55","0.00","cancelado",""),
(4,1,"2024-12-24","169.00","0.00","cancelado",""),
(5,1,"2025-01-02","98.69","0.00","activo",""),
(6,1,"2025-01-03","102.64","0.00","activo",""),
(7,2,"2025-01-03","29.00","0.00","activo","");


SET foreign_key_checks = 1;
